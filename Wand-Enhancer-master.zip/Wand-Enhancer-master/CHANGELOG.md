# Changelog

This file is the source of truth for release notes.
The newest entry must match the version in `WandEnhancer/Properties/AssemblyInfo.cs`.

## [1.0.9.3] - 2026-07-04

### Fixes

- Fixed the Remote Web Panel no longer applying on newer Wand builds and reporting "unsupported version". The remote bridge patches now resolve Wand's minified internal names dynamically instead of relying on hardcoded ones that broke on Wand updates. #118 #123 #124 #126
- Fixed Pro reverting to Free (with random sign-outs and the return of ads and the time limit) after linking a phone with Wand's mobile activation code. That native pairing triggers a server-side sign-out on a patched client, so the patcher now disables it; use the built-in Remote Web Panel to control Wand from another device instead. #120

## [1.0.9.2] - 2026-06-28

### Important

- Official releases no longer include downloadable `.exe` files. To update, sync your fork and rerun the `Build executable` workflow, or follow the instructions in [How to use](https://github.com/k1tbyte/Wand-Enhancer#-how-to-use).

### Changed

- Removed the built-in WandEnhancer updater. Official GitHub releases no longer ship executable assets.
- Removed System.Net.Http
- Removed self-signed certificate generation to prevent AV false positives.
- Switched official releases to publish release notes only.

## [1.0.9.1] - 2026-06-24

### Fixes

- Fixed Pro features disappearing after a day or two when Wand refreshed account data in the background; account store updates now preserve the patched active subscription by @Kava-4 in #110. Related issue #106
- Fixed the new Pro account reducer guard so normal account updates do not fail while keeping Pro active.

## [1.0.9.0] - 2026-06-15

### Features

- The Remote Web Panel now shows mod names, descriptions, and instructions translated to your WeMod account language by @YifePlayte in #98. Related issue: #85
- Added a language selector to the Remote Web Panel (English, Russian, German, French, Spanish, Simplified Chinese) with automatic detection from the browser language.

### Improvements

- Release builds are now code-signed, which reduces false-positive antivirus and VirusTotal detections.
- Reworked the Remote Web Panel internals around feature capabilities for easier maintenance, with no change to existing behavior.

## [1.0.8.4] - 2026-06-10

### Fixes

- Fixed QR code issues on the latest Wand version.
- Fixed application hang that occurred after Wand updates with pending patches.

## [1.0.8.3] - 2026-06-06

### Fixes

- Fixed the Remote Web Panel patches so they reliably apply on newer Wand builds by making the remote bridge patch anchors version-resilient.
- Fixed Pro activation being lost after changing the app language; the account language endpoint now keeps the patched subscription.
- Fixed "WeMod directory not found" when Wand/WeMod is installed outside the default location or only one brand folder exists. The patcher now also resolves the install directory from a running Wand/WeMod process. #82
- Hid the Pro "Remote" onboarding card in the Explore Pro benefits dialog. #86

## [1.0.8.2] - 2026-05-15

### Fixes

- Rolled back an incorrect Disable Updates patch fix that introduced a `SyntaxError` preventing Wand from launching.

## [1.0.8.1] - 2026-05-15

### Fixes

- Fixed a syntax error in the Disable Updates patch that prevented Wand from launching. #70
- Fixed an issue where the Remote Web Panel WebSocket connection wouldn't automatically reconnect when turning returning to the app or turning on the screen.
- Reduced battery consumption and device heating on mobile device by optimizing heavy UI blur effects and eliminating unnecessary React re-renders in the Remote Web Panel. #67

## [1.0.8.0] - 2026-05-06

### Features

- Added the My Games list to the Remote Panel with remote start and stop actions.
- Improved the Remote Panel with new UI and overall UX.
- Added an update dialog with release notes and access to full patch notes.

### Improvements

- Optimized and sped up patching and ASAR unpack/pack operations.

### Fixes

- Fixed in-place handling of unpacked `app.asar.unpacked` assets during packing to avoid locked-file failures.
- Fixed local network IP detection for QR-based Remote Panel pairing, so the app no longer picks Cloudflare, VMware, and similar non-LAN adapters by mistake.

## [1.0.7.0] - 2026-05-01

### Features

- New Remote Web Panel: control local app features from a phone or another PC over the local network via QR code connection. #37
- Custom Script Loader: inject and execute custom user `.js` scripts directly into the Wand renderer process via the patch modal.
- Added the ability to export and copy application logs from the UI.
- Stabilized the DevTools on `F12` patch.
- Added a repository mirror on GitLab. #47

### Fixes

- Fixed ASAR unpacking failures on locked files or missing entries. #63 #57

## [1.0.6.0] - 2025-12-14

### Fixes

- Fixed issues related to Wand `12.5.1`. #35
- Fixed a bug where the patch could not be reapplied after restoring without restarting the patcher.
- Removed the redundant telemetry removal option from patch settings.

### Features

- Added localization support.
- Added the patch option to open Wand DevTools with `F12`.

## [1.0.5.0] - 2025-11-30

### Fixes

- Fixed the issue where games detected the debugger. #33 #23 #19 #13

### Breaking Changes

- Removed patch methods.
- Removed shortcut launch.
- Removed automatic patching for new versions because it is not compatible with the current patch method.

### Notes

- This version is incompatible with previous versions of the patcher. Before updating, previous patches must be rolled back.
- With the current method, the patcher only needs to be run once to apply the patch.
- Thanks to issue #12 for sharing the patching method used here.

## [1.0.4.0] - 2025-11-05

### Features

- Added backward compatibility for older WeMod versions so both legacy WeMod and the newer Wand builds can be patched.
- Added manual version management for patches, including separate patches and shortcuts for individual WeMod or Wand versions.

## [1.0.3.0] - 2025-11-03

### Fixes

- Fixed issues related to the WeMod to Wand rebrand. #24

## [1.0.2.0] - 2025-04-09

### Fixes

- Fixed a performance issue when a process with an applied patch was scanned again.
- Fixed exception propagation into the WeMod process. #11

## [1.0.1.0] - 2025-04-01

### Fixes

- Fixed WeMod overlay breakage when using the runtime patch.

## [1.0.0.0] - 2025-03-24

### Changes

- Replaced Electron with WPF.
- Reduced the `.exe` size by more than 70x.
- Updated the UI.
- Added two types of patching.
- Fixed hotkeys breaking after patching.
- Added patch recovery.
- Removed external dependencies such as Electron and ASAR tooling from runtime.
- Added a patch option to disable WeMod updates.

### Notes

- VirusTotal detection increased with the new patching method.

## [0.0.1] - 2025-01-04

### Changes

- Basic ElectronJS wrapper over the original script.
